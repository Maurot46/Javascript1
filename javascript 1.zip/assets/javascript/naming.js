var $1_pet_preferito = 'gatto';
console.log($1_pet_preferito);

/*var pet = 'gatto';
var Pet = 'cane';*/
var petPreferito1 = 'criceto';
var PetPreferito2 = 'coniglio';

document.getElementById('pet').innerHTML += petPreferito1 + ' ' + PetPreferito2;

var $pet = 'giraffa';
console.log($pet);
var _pet = 'leone';
console.log(_pet);
var _pet2 = 'pantera';
document.write(_pet2);

var _12 = 6 + 6;
console.log(_12);